#include <stdio.h>


int MyFunction()
{
	printf("library\n");
	return 0;
}
